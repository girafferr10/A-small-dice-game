import tkinter as tk
import random


gacha_count = 0
rare_pity = 0
epic_pity = 0
legendary_pity = 0
lost_50_50 = False


ON_BANNER = "Yippe Die"


unlocked_dice = set()
pull_history = []  

def draw_dice(canvas, value):
    canvas.delete("all")
    canvas.create_rectangle(10, 10, 90, 90, fill="white", outline="black")
    positions = {
        1: [(50, 50)],
        2: [(30, 30), (70, 70)],
        3: [(30, 30), (50, 50), (70, 70)],
        4: [(30, 30), (30, 70), (70, 30), (70, 70)],
        5: [(30, 30), (30, 70), (50, 50), (70, 30), (70, 70)],
        6: [(30, 30), (30, 50), (30, 70), (70, 30), (70, 50), (70, 70)]
    }
    if 1 <= value <= 6:
        for x, y in positions[value]:
            canvas.create_oval(x-5, y-5, x+5, y+5, fill="black")
    else:
        canvas.create_text(50, 50, text=":)", font=("Arial", 20), fill="black")

def open_gacha_window(root, dice_book, inventory, update_money, get_money, set_money):
    from functools import partial

    banner_state = {"current": "Limited 1"}

    banners = {
        "Limited 1": {"rarity_cap": "Legendary", "banner_die": "Yippe Die"},
        "Limited 2": {"rarity_cap": "Legendary", "banner_die": "Yippe Die"},
        "Limited 3": {"rarity_cap": "Legendary", "banner_die": "Yippe Die"},
        "Standard": {"rarity_cap": "Epic", "banner_die": None},
        "Items": {"disabled": True}
    }

    gacha_win = tk.Toplevel(root)
    gacha_win.title("Gacha")
    gacha_win.geometry("1000x700")
    gacha_win.configure(bg="#D3D3D3")

    
    tab_frame = tk.Frame(gacha_win, bg="#D3D3D3")
    tab_frame.pack(pady=5)

    def switch_banner(name):
        if banners.get(name, {}).get("disabled"):
            return
        banner_state["current"] = name
        banner_label.config(text=f"{name} Banner")
        update_explanation()

    for name in banners:
        state = "disabled" if banners[name].get("disabled") else "normal"
        tk.Button(tab_frame, text=name, command=partial(switch_banner, name),
                  state=state, bg="white", fg="black", width=12).pack(side="left", padx=5)

    banner_label = tk.Label(gacha_win, text="Limited 1 Banner", font=("Arial", 18), bg="#D3D3D3")
    banner_label.pack(pady=5)

    explanation_label = tk.Label(gacha_win, text="", font=("Arial", 11), bg="#D3D3D3", justify="left")
    explanation_label.pack()

    def update_explanation():
        current = banner_state["current"]
        if current == "Standard":
            text = (
                "Standard Banner:\n"
                "- Pulls cost $100 each\n"
                "- Rarity range: Common to Epic\n"
                "- No Legendaries available\n"
                "- No pity system"
            )
        else:
            text = (
                f"{current} Banner:\n"
                "- Pulls cost $100 each\n"
                "- Base Legendary chance: 1%\n"
                "- Soft pity starts at pull 78 (5%)\n"
                "- Increases by 5% per pull until 100% at pull 97\n"
                "- 50/50 chance for banner die: Yippe Die\n"
                "- Guaranteed banner if you lose 50/50 once"
            )
        explanation_label.config(text=text)

    update_explanation()

    result_frame = tk.Frame(gacha_win, bg="#D3D3D3")
    result_frame.pack(pady=10)

    
    pity_label = tk.Label(gacha_win, text="", font=("Arial", 10), bg="#D3D3D3", anchor="se", justify="right")
    pity_label.place(relx=1.0, rely=1.0, anchor="se", x=-10, y=-10)

    def update_pity_display():
        pity_label.config(text=f"Pity — Rare: {rare_pity} | Epic: {epic_pity} | Legendary: {legendary_pity}")

    def show_history():
        history_win = tk.Toplevel(gacha_win)
        history_win.title("Pull History")
        history_win.geometry("600x400")
        history_win.configure(bg="#D3D3D3")

        canvas = tk.Canvas(history_win, bg="#D3D3D3")
        scrollbar = tk.Scrollbar(history_win, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg="#D3D3D3")

        scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        for i, (die, rarity) in enumerate(reversed(pull_history[-1000:])):
            tk.Label(scroll_frame, text=f"{len(pull_history)-i}. {die} ({rarity})", font=("Arial", 10), bg="#D3D3D3").pack(anchor="w")

    def roll_gacha(times):
        nonlocal result_frame
        for widget in result_frame.winfo_children():
            widget.destroy()

        current = banner_state["current"]
        if banners.get(current, {}).get("disabled"):
            return

        cost = 100 * times
        if get_money() < cost:
            return
        set_money(get_money() - cost)

        pulled = []
        global gacha_count, rare_pity, epic_pity, legendary_pity, lost_50_50

        for _ in range(times):
            rarity = "Common"
            gacha_count += 1
            rare_pity += 1
            epic_pity += 1
            legendary_pity += 1

            if current == "Standard":
                roll = random.randint(1, 100)
                if roll <= 20:
                    rarity = "Epic"
                    epic_pity = 0
                elif roll <= 60:
                    rarity = "Rare"
                    rare_pity = 0
                else:
                    rarity = "Common"
            else:
                if legendary_pity >= 97:
                    rarity = "Legendary"
                    legendary_pity = 0
                else:
                    pity_bonus = max(0, legendary_pity - 77) * 5
                    chance = 1 + (4 if legendary_pity == 78 else pity_bonus)
                    if random.randint(1, 100) <= chance:
                        rarity = "Legendary"
                        legendary_pity = 0
                    else:
                        roll = random.randint(1, 100)
                        if roll <= 20:
                            rarity = "Epic"
                            epic_pity = 0
                        elif roll <= 60:
                            rarity = "Rare"
                            rare_pity = 0
                        else:
                            rarity = "Common"

            if rarity == "Legendary" and current != "Standard":
                if lost_50_50 or random.choice([True, False]):
                    die = banners[current]["banner_die"]
                    lost_50_50 = False
                else:
                    die = banners[current]["banner_die"]
                    lost_50_50 = True
            else:
                pool = [n for n, d in dice_book.items()
                        if d["rarity"] == rarity and
                        (current != "Standard" or rarity != "Legendary")]
                die = random.choice(pool)

            inventory.append(die)
            unlocked_dice.add(die)
            pull_history.append((die, rarity))
            if len(pull_history) > 1000:
                pull_history.pop(0)
            pulled.append((die, dice_book[die]))

        update_money()
        update_pity_display()

        
        overlay = tk.Toplevel(gacha_win)
        overlay.title("Pull Results")
        overlay.geometry("800x400")
        overlay.configure(bg="#D3D3D3")

        grid = tk.Frame(overlay, bg="#D3D3D3")
        grid.pack(pady=20)

        for i, (die, data) in enumerate(pulled):
            frame = tk.Frame(grid, bg="#D3D3D3", bd=1, relief="solid")
            frame.grid(row=i//5, column=i%5, padx=10, pady=10)

            canvas = tk.Canvas(frame, width=100, height=100, bg="#D3D3D3", highlightthickness=0)
            canvas.pack()
            max_val = max([s for s in data["sides"] if isinstance(s, int)], default=0)
            draw_dice(canvas, max_val)

            tk.Label(frame, text=die, font=("Arial", 10), bg="#D3D3D3").pack()
            tk.Label(frame, text=data["rarity"], font=("Arial", 9), bg="#D3D3D3", fg="gray").pack()

        tk.Button(overlay, text="Close", command=overlay.destroy, bg="white", fg="black").pack(pady=10)

    
    button_frame = tk.Frame(gacha_win, bg="#D3D3D3")
    button_frame.pack(pady=10)

    tk.Button(button_frame, text="1 Pull ($100)", command=lambda: roll_gacha(1), bg="white", fg="black", width=15).grid(row=0, column=0, padx=5)
    tk.Button(button_frame, text="10 Pulls ($1000)", command=lambda: roll_gacha(10), bg="white", fg="black", width=15).grid(row=0, column=1, padx=5)
    tk.Button(button_frame, text="View History", command=show_history, bg="white", fg="black", width=15).grid(row=0, column=2, padx=5)
    tk.Button(button_frame, text="Close", command=gacha_win.destroy, bg="white", fg="black", width=15).grid(row=0, column=3, padx=5)
