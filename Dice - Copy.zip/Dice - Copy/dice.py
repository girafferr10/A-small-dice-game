import tkinter as tk
import random
import time
import json
import os
from book.book_def import open_dice_book
from book.dice_definitions import dice_book
from gacha import gacha_count, rare_pity, epic_pity, legendary_pity, lost_50_50, open_gacha_window, unlocked_dice


money = 100
slot_count = 4
max_slots = 10
cooldown_time = 5
min_cooldown = 1
luck_bonus = 0
max_luck = 5
dice_slots = [None] * max_slots
cooldowns = [0] * max_slots
inventory = []


root = tk.Tk()
root.title("Dice Gacha Tycoon")
root.geometry("1000x700")
root.configure(bg="#D3D3D3")

money_label = tk.Label(root, text=f"Money: ${money}", font=("Arial", 16), bg="#D3D3D3", fg="black")
money_label.pack(pady=10)

menu_frame = tk.Frame(root, bg="#D3D3D3")
menu_frame.pack(pady=5)

tk.Button(menu_frame, text="Roll All", command=lambda: roll_all(), font=("Arial", 12), bg="white", fg="black").grid(row=0, column=0, padx=5)
tk.Button(menu_frame, text="Gacha", command=lambda: open_gacha(), font=("Arial", 12), bg="white", fg="black").grid(row=0, column=1, padx=5)
tk.Button(menu_frame, text="Skill Tree", command=lambda: open_skill_tree(), font=("Arial", 12), bg="white", fg="black").grid(row=0, column=2, padx=5)
tk.Button(menu_frame, text="Dice Book", command=lambda: open_dice_book(root, inventory, dice_slots), font=("Arial", 12), bg="white", fg="black").grid(row=0, column=3, padx=5)
tk.Button(menu_frame, text="Inventory", command=lambda: open_inventory(), font=("Arial", 12), bg="white", fg="black").grid(row=0, column=4, padx=5)

slot_frame = tk.Frame(root, bg="#D3D3D3")
slot_frame.pack()
slot_widgets = []

def update_money():
    money_label.config(text=f"Money: ${money}")

def set_money(value):
    global money
    money = value
    update_money()

def draw_dice(canvas, value):
    canvas.delete("all")
    canvas.create_rectangle(10, 10, 90, 90, fill="white", outline="black")
    positions = {
        1: [(50, 50)],
        2: [(30, 30), (70, 70)],
        3: [(30, 30), (50, 50), (70, 70)],
        4: [(30, 30), (30, 70), (70, 30), (70, 70)],
        5: [(30, 30), (30, 70), (50, 50), (70, 30), (70, 70)],
        6: [(30, 30), (30, 50), (30, 70), (70, 30), (70, 50), (70, 70)]
    }
    if value in positions:
        for x, y in positions[value]:
            canvas.create_oval(x-5, y-5, x+5, y+5, fill="black")
    elif isinstance(value, int):
        canvas.create_text(50, 50, text=":)", font=("Arial", 20), fill="black")
    else:
        canvas.create_text(50, 50, text="?", font=("Arial", 20), fill="black")

def roll_die(index):
    global money
    now = time.time()
    if now < cooldowns[index]:
        return
    die = dice_slots[index]
    if not die:
        return
    sides = dice_book[die]["sides"]
    roll = random.choice(sides)

    if isinstance(roll, int):
        slot_widgets[index]["label"].config(text=f"{die}\nRolled: {roll}{' :)' if roll >= 7 else ''}")
        cooldowns[index] = now + cooldown_time
        earned = int(roll * 10 * (1 + luck_bonus))
        money += earned
    else:
        slot_widgets[index]["label"].config(text=f"{die}\nRolled: :( (punished)")
        cooldowns[index] = now + 60

    draw_dice(slot_widgets[index]["canvas"], roll if isinstance(roll, int) else 0)
    update_money()

def sell_die(index):
    global money
    die = dice_slots[index]
    if not die:
        return
    avg = sum([s for s in dice_book[die]["sides"] if isinstance(s, int)]) / 6
    value = int(avg * 10)
    money += value
    dice_slots[index] = None
    slot_widgets[index]["label"].config(text="Empty Slot")
    slot_widgets[index]["canvas"].delete("all")
    update_money()

def roll_all():
    for i in range(slot_count):
        if time.time() >= cooldowns[i] and dice_slots[i]:
            roll_die(i)

def update_slots():
    for i in range(slot_count):
        add_slot(i)

def update_cooldowns():
    now = time.time()
    for i in range(slot_count):
        if dice_slots[i]:
            cd = max(0, int(cooldowns[i] - now))
            slot_widgets[i]["cd"].config(text=f"CD: {cd}s")
        else:
            slot_widgets[i]["cd"].config(text="")
    root.after(1000, update_cooldowns)

def add_slot(index):
    frame = tk.Frame(slot_frame, bg="#D3D3D3", padx=10, pady=10)
    frame.grid(row=index//5, column=index%5)
    canvas = tk.Canvas(frame, width=100, height=100, bg="#D3D3D3", highlightthickness=0)
    canvas.pack()
    text_label = tk.Label(frame, text="Empty Slot", font=("Arial", 12), bg="#D3D3D3", fg="black")
    text_label.pack()
    cd_label = tk.Label(frame, text="", font=("Arial", 10), bg="#D3D3D3", fg="gray")
    cd_label.pack()
    tk.Button(frame, text="Roll", command=lambda i=index: roll_die(i), bg="white", fg="black").pack(pady=2)
    tk.Button(frame, text="Sell", command=lambda i=index: sell_die(i), bg="white", fg="black").pack(pady=2)
    slot_widgets.append({"label": text_label, "canvas": canvas, "cd": cd_label})
def open_gacha():
    open_gacha_window(root, dice_book, inventory, update_money, lambda: money, set_money)

def open_inventory():
    inv_win = tk.Toplevel(root)
    inv_win.title("Inventory")
    inv_win.geometry("700x500")
    inv_win.configure(bg="#D3D3D3")

    tk.Label(inv_win, text="Inventory", font=("Arial", 16), bg="#D3D3D3").pack(pady=10)

    sort_frame = tk.Frame(inv_win, bg="#D3D3D3")
    sort_frame.pack()
    sort_var = tk.StringVar(value="Name")
    tk.Label(sort_frame, text="Sort by:", bg="#D3D3D3").pack(side="left")
    tk.OptionMenu(sort_frame, sort_var, "Name", "Rarity").pack(side="left")

    canvas = tk.Canvas(inv_win, bg="#D3D3D3", highlightthickness=0)
    scrollbar = tk.Scrollbar(inv_win, orient="vertical", command=canvas.yview)
    scroll_frame = tk.Frame(canvas, bg="#D3D3D3")

    scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    rarity_rank = {"Common": 0, "Rare": 1, "Epic": 2, "Legendary": 3}

    def draw_scaled_dice(canvas, value):
        canvas.delete("all")
        w = canvas.winfo_width() or 100
        h = canvas.winfo_height() or 100
        canvas.create_rectangle(10, 10, w-10, h-10, fill="white", outline="black")
        positions = {
            1: [(w//2, h//2)],
            2: [(w//3, h//3), (2*w//3, 2*h//3)],
            3: [(w//3, h//3), (w//2, h//2), (2*w//3, 2*h//3)],
            4: [(w//3, h//3), (w//3, 2*h//3), (2*w//3, h//3), (2*w//3, 2*h//3)],
            5: [(w//3, h//3), (w//3, 2*h//3), (w//2, h//2), (2*w//3, h//3), (2*w//3, 2*h//3)],
            6: [(w//3, h//4), (w//3, h//2), (w//3, 3*h//4), (2*w//3, h//4), (2*w//3, h//2), (2*w//3, 3*h//4)]
        }
        if 1 <= value <= 6:
            for x, y in positions[value]:
                canvas.create_oval(x-5, y-5, x+5, y+5, fill="black")
        else:
            canvas.create_text(w//2, h//2, text=":)", font=("Arial", int(min(w,h)//5)), fill="black")

    def bind_draw(canvas, value):
        canvas.bind("<Configure>", lambda e, c=canvas, v=value: draw_scaled_dice(c, v))

    def refresh_inventory():
        for widget in scroll_frame.winfo_children():
            widget.destroy()

        if sort_var.get() == "Name":
            sorted_inv = sorted(inventory)
        else:
            sorted_inv = sorted(inventory, key=lambda d: rarity_rank.get(dice_book[d]["rarity"], 99))

        for i, die in enumerate(sorted_inv):
            frame = tk.Frame(scroll_frame, bg="#D3D3D3", bd=1, relief="solid")
            frame.grid(row=i//5, column=i%5, padx=10, pady=10, sticky="nsew")
            scroll_frame.grid_columnconfigure(i%5, weight=1)
            scroll_frame.grid_rowconfigure(i//5, weight=1)


            canvas_die = tk.Canvas(frame, width=100, height=100, bg="#D3D3D3", highlightthickness=0)
            canvas_die.pack(fill="both", expand=True)
            sides = dice_book[die]["sides"]
            max_val = max([s for s in sides if isinstance(s, int)], default=0)
            bind_draw(canvas_die, max_val)

            tk.Label(frame, text=die, font=("Arial", 10), bg="#D3D3D3").pack()
            tk.Label(frame, text=dice_book[die]["rarity"], font=("Arial", 9), bg="#D3D3D3", fg="gray").pack()
            tk.Button(frame, text="Place", command=lambda d=die: place_die(d, inv_win), bg="white", fg="black").pack()

    sort_var.trace_add("write", lambda *args: refresh_inventory())
    refresh_inventory()



    def show_die_info(die):
        info_win = tk.Toplevel(book_win)
        info_win.title(die)
        info_win.geometry("300x200")
        info_win.configure(bg="#D3D3D3")
        tk.Label(info_win, text=die, font=("Arial", 14), bg="#D3D3D3").pack(pady=10)
        tk.Label(info_win, text=f"Rarity: {dice_book[die]['rarity']}", bg="#D3D3D3").pack()
        tk.Label(info_win, text=f"Sides: {dice_book[die]['sides']}", bg="#D3D3D3").pack()

    def draw_scaled_dice(canvas, value):
        canvas.delete("all")
        w = canvas.winfo_width() or 100
        h = canvas.winfo_height() or 100
        canvas.create_rectangle(10, 10, w-10, h-10, fill="white", outline="black")
        positions = {
            1: [(w//2, h//2)],
            2: [(w//3, h//3), (2*w//3, 2*h//3)],
            3: [(w//3, h//3), (w//2, h//2), (2*w//3, 2*h//3)],
            4: [(w//3, h//3), (w//3, 2*h//3), (2*w//3, h//3), (2*w//3, 2*h//3)],
            5: [(w//3, h//3), (w//3, 2*h//3), (w//2, h//2), (2*w//3, h//3), (2*w//3, 2*h//3)],
            6: [(w//3, h//4), (w//3, h//2), (w//3, 3*h//4), (2*w//3, h//4), (2*w//3, h//2), (2*w//3, 3*h//4)]
        }
        if 1 <= value <= 6:
            for x, y in positions[value]:
                canvas.create_oval(x-5, y-5, x+5, y+5, fill="black")
        else:
            canvas.create_text(w//2, h//2, text=":)", font=("Arial", int(min(w,h)//5)), fill="black")

    def refresh_book():
        for widget in scroll_frame.winfo_children():
            widget.destroy()

        sorted_book = sorted(dice_book.items(), key=lambda x: x[0] if sort_var.get() == "Name" else x[1]["rarity"])
        for i, (die, data) in enumerate(sorted_book):
            frame = tk.Frame(scroll_frame, bg="#D3D3D3", bd=1, relief="solid", padx=5, pady=5)
            frame.grid(row=i//5, column=i%5, padx=10, pady=10)

            canvas_die = tk.Canvas(frame, width=100, height=100, bg="#D3D3D3", highlightthickness=0)
            canvas_die.pack(fill="both", expand=True)

            if die in inventory or die in unlocked_dice or die in dice_slots:
                max_val = max([s for s in data["sides"] if isinstance(s, int)], default=0)
                canvas_die.bind("<Configure>", lambda e, c=canvas_die, v=max_val: draw_scaled_dice(c, v))
                tk.Label(frame, text=die, font=("Arial", 10), bg="#D3D3D3").pack()
                tk.Label(frame, text=data["rarity"], font=("Arial", 9), bg="#D3D3D3", fg="gray").pack()
                tk.Button(frame, text="Info", command=lambda d=die: show_die_info(d), bg="white", fg="black").pack()
            else:
                canvas_die.bind("<Configure>", lambda e, c=canvas_die: draw_scaled_dice(c, 0))
                tk.Label(frame, text="?", font=("Arial", 10), bg="#D3D3D3").pack()
                tk.Label(frame, text=data["rarity"], font=("Arial", 9), bg="#D3D3D3", fg="gray").pack()

    sort_var.trace_add("write", lambda *args: refresh_book())
    refresh_book()

def place_die(die, window):
    unlocked_dice.add(die)
    place_win = tk.Toplevel(window)
    place_win.title(f"Place {die}")
    place_win.geometry("300x300")
    place_win.configure(bg="#D3D3D3")

    tk.Label(place_win, text=f"Choose a slot for {die}", font=("Arial", 14), bg="#D3D3D3").pack(pady=10)

    for i in range(slot_count):
        def assign(slot=i):
            if time.time() >= cooldowns[slot]:
                if dice_slots[slot]:
                    inventory.append(dice_slots[slot])
                dice_slots[slot] = die
                slot_widgets[slot]["label"].config(text=die)
                draw_dice(slot_widgets[slot]["canvas"], 1)
                if die in inventory:
                    inventory.remove(die)
                place_win.destroy()
                window.destroy()
                update_money()
        tk.Button(place_win, text=f"Slot {i+1}", command=assign, bg="white", fg="black").pack(pady=2)

def open_skill_tree():
    tree_win = tk.Toplevel(root)
    tree_win.title("Skill Tree")
    tree_win.geometry("400x400")
    tree_win.configure(bg="#D3D3D3")

    def buy_upgrade(name):
        global money, cooldown_time, slot_count, luck_bonus
        if money < 200:
            return

        if name == "Cooldown" and cooldown_time > min_cooldown:
            cooldown_time -= 1
            money -= 200

        elif name == "Slots" and slot_count < max_slots:
            slot_count += 1
            dice_slots[slot_count - 1] = None
            cooldowns[slot_count - 1] = 0
            add_slot(slot_count - 1)
            money -= 200

        elif name == "Luck" and luck_bonus < max_luck:
            luck_bonus += 0.5
            money -= 200

        update_money()
        tree_win.destroy()
        open_skill_tree()

    tk.Label(tree_win, text="Skill Tree", font=("Arial", 16), bg="#D3D3D3", fg="black").pack(pady=10)
    tk.Button(tree_win, text="Reduce Cooldown ($200)", command=lambda: buy_upgrade("Cooldown"),
              bg="white", fg="black", state="normal" if cooldown_time > min_cooldown else "disabled").pack(pady=5)
    tk.Label(tree_win, text="Decreases time between rolls for all dice (min 1s).", bg="#D3D3D3").pack()

    tk.Button(tree_win, text="Add Slot ($200)", command=lambda: buy_upgrade("Slots"),
              bg="white", fg="black", state="normal" if slot_count < max_slots else "disabled").pack(pady=5)
    tk.Label(tree_win, text="Adds a new dice slot (max 10).", bg="#D3D3D3").pack()

    tk.Button(tree_win, text="Increase Luck ($200)", command=lambda: buy_upgrade("Luck"),
              bg="white", fg="black", state="normal" if luck_bonus < max_luck else "disabled").pack(pady=5)
    tk.Label(tree_win, text="Increases roll earnings slightly for all dice (max +5.0).", bg="#D3D3D3").pack()
def save_game():
    save_data = {
        "money": money,
        "inventory": inventory,
        "dice_slots": dice_slots[:slot_count],
        "slot_count": slot_count,
        "upgrades": {
            "cooldown_time": cooldown_time,
            "luck_bonus": luck_bonus
        },
        "unlocked_dice": list(unlocked_dice)
    }
    save_path = r"C:\Users\948425\Downloads\dice\saves.json"
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, "w") as f:
        json.dump(save_data, f)

def load_game():
    global money, inventory, dice_slots, slot_count, cooldown_time, luck_bonus, unlocked_dice
    save_path = r"C:\Users\948425\Downloads\dice\saves.json"
    if os.path.exists(save_path):
        with open(save_path, "r") as f:
            data = json.load(f)
            money = data.get("money", 100)
            inventory = data.get("inventory", [])
            slot_count = data.get("slot_count", 4)
            upgrades = data.get("upgrades", {})
            cooldown_time = upgrades.get("cooldown_time", 5)
            luck_bonus = upgrades.get("luck_bonus", 0)
            unlocked_dice = set(data.get("unlocked_dice", []))
            for i in range(slot_count):
                dice_slots[i] = data["dice_slots"][i] if i < len(data["dice_slots"]) else None

def on_close():
    save_game()
    root.destroy()


try:
    load_game()
    update_slots()
    for i in range(slot_count):
        if dice_slots[i]:
            slot_widgets[i]["label"].config(text=dice_slots[i])
            draw_dice(slot_widgets[i]["canvas"], 1)
    update_money()
    update_cooldowns()
    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()

except Exception as e:
    import tkinter.messagebox as msg
    msg.showerror("Crash", f"An error occurred:\n{e}")

input("Press Enter to exit...")
