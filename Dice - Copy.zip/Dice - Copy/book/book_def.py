import tkinter as tk
from book.dice_definitions import dice_book
from gacha import unlocked_dice

def open_dice_book(root, inventory, dice_slots):
    book_win = tk.Toplevel(root)
    book_win.title("Dice Book")
    book_win.geometry("700x600")
    book_win.configure(bg="#D3D3D3")

    tk.Label(book_win, text="Dice Book", font=("Arial", 18), bg="#D3D3D3", fg="black").pack(pady=10)

    sort_frame = tk.Frame(book_win, bg="#D3D3D3")
    sort_frame.pack()
    sort_var = tk.StringVar(value="Name")
    tk.Label(sort_frame, text="Sort by:", bg="#D3D3D3").pack(side="left")
    tk.OptionMenu(sort_frame, sort_var, "Name", "Rarity").pack(side="left")

    canvas = tk.Canvas(book_win, bg="#D3D3D3", highlightthickness=0)
    scrollbar = tk.Scrollbar(book_win, orient="vertical", command=canvas.yview)
    scroll_frame = tk.Frame(canvas, bg="#D3D3D3")

    scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    rarity_rank = {"Common": 0, "Rare": 1, "Epic": 2, "Legendary": 3}

    def draw_scaled_dice(canvas, value):
        canvas.delete("all")
        w = canvas.winfo_width() or 100
        h = canvas.winfo_height() or 100
        canvas.create_rectangle(10, 10, w-10, h-10, fill="white", outline="black")
        positions = {
            1: [(w//2, h//2)],
            2: [(w//3, h//3), (2*w//3, 2*h//3)],
            3: [(w//3, h//3), (w//2, h//2), (2*w//3, 2*h//3)],
            4: [(w//3, h//3), (w//3, 2*h//3), (2*w//3, h//3), (2*w//3, 2*h//3)],
            5: [(w//3, h//3), (w//3, 2*h//3), (w//2, h//2), (2*w//3, h//3), (2*w//3, 2*h//3)],
            6: [(w//3, h//4), (w//3, h//2), (w//3, 3*h//4), (2*w//3, h//4), (2*w//3, h//2), (2*w//3, 3*h//4)]
        }
        if 1 <= value <= 6:
            for x, y in positions[value]:
                canvas.create_oval(x-5, y-5, x+5, y+5, fill="black")
        else:
            canvas.create_text(w//2, h//2, text=":)", font=("Arial", int(min(w,h)//5)), fill="black")

    def bind_draw(canvas, value):
        canvas.bind("<Configure>", lambda e, c=canvas, v=value: draw_scaled_dice(c, v))

    def show_die_info(die):
        info_win = tk.Toplevel(book_win)
        info_win.title(die)
        info_win.geometry("300x200")
        info_win.configure(bg="#D3D3D3")
        tk.Label(info_win, text=die, font=("Arial", 14), bg="#D3D3D3").pack(pady=10)
        tk.Label(info_win, text=f"Rarity: {dice_book[die]['rarity']}", bg="#D3D3D3").pack()
        tk.Label(info_win, text=f"Sides: {dice_book[die]['sides']}", bg="#D3D3D3").pack()

    def refresh_book():
        for widget in scroll_frame.winfo_children():
            widget.destroy()

        sorted_book = sorted(dice_book.items(), key=lambda x: x[0] if sort_var.get() == "Name" else rarity_rank.get(x[1]["rarity"], 99))
        for i, (die, data) in enumerate(sorted_book):
            frame = tk.Frame(scroll_frame, bg="#D3D3D3", bd=1, relief="solid")
            frame.grid(row=i//5, column=i%5, padx=10, pady=10, sticky="nsew")
            scroll_frame.grid_columnconfigure(i%5, weight=1)
            scroll_frame.grid_rowconfigure(i//5, weight=1)

            canvas_die = tk.Canvas(frame, width=100, height=100, bg="#D3D3D3", highlightthickness=0)
            canvas_die.pack(fill="both", expand=True)

            if die in inventory or die in unlocked_dice or die in dice_slots:
                max_val = max([s for s in data["sides"] if isinstance(s, int)], default=0)
                bind_draw(canvas_die, max_val)
                tk.Label(frame, text=die, font=("Arial", 10), bg="#D3D3D3").pack()
                tk.Label(frame, text=data["rarity"], font=("Arial", 9), bg="#D3D3D3", fg="gray").pack()
                tk.Button(frame, text="Info", command=lambda d=die: show_die_info(d), bg="white", fg="black").pack()
            else:
                bind_draw(canvas_die, 0)
                tk.Label(frame, text="?", font=("Arial", 10), bg="#D3D3D3").pack()
                tk.Label(frame, text=data["rarity"], font=("Arial", 9), bg="#D3D3D3", fg="gray").pack()

    sort_var.trace_add("write", lambda *args: refresh_book())
    refresh_book()
