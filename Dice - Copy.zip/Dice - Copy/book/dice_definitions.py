dice_book = {
    "Default Die": {
        "sides": [1, 2, 3, 4, 5, 6],
        "rarity": "Common",
        "description": "A basic die with balanced sides."
    },
    "Spike Die": {
        "sides": [0, 0, 7, 8, 9, 10],
        "rarity": "Rare",
        "description": "High risk, high reward. Spikes or blanks."
    },
    "Ghost Die": {
        "sides": [1, 1, 1, 6, 6, 6],
        "rarity": "Rare",
        "description": "Haunted by symmetry. Low or high."
    },
    "Blaze Die": {
        "sides": [3, 3, 3, 12, "bad", "bad"],
        "rarity": "Epic",
        "description": "Burns bright or burns out."
    },
    "Titan Die": {
        "sides": [5, 5, 5, 5, 10, 15],
        "rarity": "Epic",
        "description": "Heavy hitter with consistent power."
    },
    "Nova Die": {
        "sides": [2, 4, 6, 8, 10, 12],
        "rarity": "Epic",
        "description": "A cosmic spread of possibilities."
    },
    "Echo Die": {
        "sides": [1, 2, 3, 1, 2, 3],
        "rarity": "Common",
        "description": "Repeats itself. Low but predictable."
    },
    "Chaos Die": {
        "sides": ["bad", "bad", "bad", 20, 20, 20],
        "rarity": "Legendary",
        "description": "Total chaos. All or nothing."
    },
    "Frost Die": {
        "sides": [2, 2, 2, 2, 2, 12],
        "rarity": "Rare",
        "description": "Cold and steady with a surprise."
    },
    "Volt Die": {
        "sides": [1, 3, 5, 7, 9, 11],
        "rarity": "Epic",
        "description": "Electric energy. Always moving."
    },
    "Yippe Die": {
        "sides": [12, 12, 12, 12, 12, 12],
        "rarity": "Legendary",
        "description": "Yippe."
    }
}
